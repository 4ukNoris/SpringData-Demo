package softuni.exam.util.paths;

import java.nio.file.Path;

public class PathJSON {

    public static Path READ_COUNTRIES_PATH = Path.of("src/main/resources/files/json/countries.json");
    public static Path READ_VOLCANOES_PATH = Path.of("src/main/resources/files/json/volcanoes.json");
}

package softuni.exam.util.paths;

import java.nio.file.Path;

public class PathXML {

    public static String READ_VOLCANOLOGISTS_PATH = "src/main/resources/files/xml/volcanologists.xml";
}

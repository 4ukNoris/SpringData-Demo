package softuni.exam.models.entity;

import softuni.exam.models.enums.VolcanoType;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "volcanoes")
public class Volcano extends BaseEntity {
//•	name - accepts char sequence (between 2 to 30 both inclusive). The values are unique in the database. It cannot be nullable.
//•	elevation - The highest point of the volcano. Accepts only positive numbers. It cannot be nullable.
//•	volcano type - categorization of the volcanoes. String enumeration,
// one of the following – CINDER_CONE, STRATOVOLCANO, SHIELD_VOLCANO, LAVA_DOME, CALDERA. It can be nullable.
//•	is active – accepts a true or false, representing whether the volcano is active or not. It cannot be nullable.
//•	last eruption – indicates when the last eruption occurred. It can be nullable.
//•	Constraint: The volcanoes table has a relation with the countries table. It can be nullable.
    @Column(nullable = false, unique = true)
    private String name;
    @Column(nullable = false)
    private Integer elevation;
    @Enumerated(EnumType.STRING)
    @Column(name = "volcano_type")
    private VolcanoType volcanoType;
    @Column(name = "is_active", nullable = false)
    private boolean isActive;
    @Column(name = "last_eruption")
    private LocalDate lastEruption;
    @ManyToOne
    private Country country;


    public Volcano() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getElevation() {
        return elevation;
    }

    public void setElevation(Integer elevation) {
        this.elevation = elevation;
    }

    public VolcanoType getVolcanoType() {
        return volcanoType;
    }

    public void setVolcanoType(VolcanoType volcanoType) {
        this.volcanoType = volcanoType;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public LocalDate getLastEruption() {
        return lastEruption;
    }

    public void setLastEruption(LocalDate lastEruption) {
        this.lastEruption = lastEruption;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}

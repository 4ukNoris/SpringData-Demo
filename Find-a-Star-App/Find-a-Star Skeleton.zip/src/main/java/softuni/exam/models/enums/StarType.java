package softuni.exam.models.enums;

public enum StarType {
    RED_GIANT, WHITE_DWARF, NEUTRON_STAR
}

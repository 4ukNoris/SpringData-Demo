package softuni.exam.models.dto;

public class ExportStarsDto {
    private String starName;

    private double lightYears;

    private String description;

    private String constellationName;

    public ExportStarsDto() {
    }

    public ExportStarsDto(String starName, double lightYears, String description, String constellationName) {
        this.starName = starName;
        this.lightYears = lightYears;
        this.description = description;
        this.constellationName = constellationName;
    }

    public String getStarName() {
        return starName;
    }

    public void setStarName(String starName) {
        this.starName = starName;
    }

    public double getLightYears() {
        return lightYears;
    }

    public void setLightYears(double lightYears) {
        this.lightYears = lightYears;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getConstellationName() {
        return constellationName;
    }

    public void setConstellationName(String constellationName) {
        this.constellationName = constellationName;
    }
}

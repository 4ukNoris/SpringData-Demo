package softuni.exam.util;

import java.nio.file.Path;

public class PathsXML {

    public static Path READ_ASTRONOMERS_PATH =
            Path.of("src/main/resources/files/xml/astronomers.xml");
}
